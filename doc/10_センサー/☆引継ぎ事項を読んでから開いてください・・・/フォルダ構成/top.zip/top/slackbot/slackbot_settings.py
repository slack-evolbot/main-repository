# -*- coding: utf-8 -*-
API_TOKEN = 'xoxb-350517610304-oISmUNkq20Tnu7BdIsWzzGYx'

# デフォルトの返答
DEFAULT_REPLY = 'すみません、よくわかりません。Sorry'

# プラグインを記述するパッケージ名のリスト
PLUGINS = ['SlackBotPlugin']
