﻿from slackbot.bot import Bot

def main():
    paspi_doorlock_bot = Bot()
    paspi_doorlock_bot.run()

# SlackBot起動
if __name__ == "__main__":
    print("start slackbot")
    main()
